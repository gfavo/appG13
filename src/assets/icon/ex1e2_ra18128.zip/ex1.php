<?php 

 $media = 5;

if($media >= 6) {
    echo "Aprovado!";
}
 else if($media < 6 && $media <= 3) {
    echo "Dependência!";
}
else {
    echo "Reprovado!";
}



?>