<?php

$velocidade_inicial = 10;
$acelercacao = 20;
$tempo = 12;

$velocidade_final = 3.6 * ($velocidade_inicial + $acelercacao * $tempo);

echo "A velocidade final do veículo é de  $velocidade_final m/s.";

?>